class Point {
  double x, y, z;

  Point(this.x, this.y, this.z);

  List<double> arrayPoint() {
    return <double>[x, y, z];
  }
}
